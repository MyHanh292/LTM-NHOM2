import socket
import hashlib
import os
from datetime import datetime

os.system('chcp 65001 > nul')

SERVER_IP = "127.0.0.1"
SERVER_PORT = 8888
BUFFER_SIZE = 1024

def strong_checksum(data: bytes) -> str:
    """Tạo mã Checksum SHA256 để kiểm tra lỗi truyền tin"""
    return hashlib.sha256(data).hexdigest()[:8]

def udp_server():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((SERVER_IP, SERVER_PORT))
    
    print("="*50)
    print(f"  UDP SERVER - Đang lắng nghe tại {SERVER_IP}:{SERVER_PORT}")
    print("="*50)

    while True:
        try:
            data, addr = sock.recvfrom(BUFFER_SIZE)
            raw_msg = data.decode("utf-8", errors='ignore')
            time_now = datetime.now().strftime("%H:%M:%S")

            if "<CHK:" in raw_msg:
                # 1. mã Checksum gốc
                content, chk_part = raw_msg.split("<CHK:")
                received_hash = chk_part.replace(">", "")
                
                # 2. Tính lại Checksum để đối chiếu
                expected_hash = strong_checksum(content.encode('utf-8'))
                
                if received_hash == expected_hash:
                    print(f"\n[{time_now}] Nhận từ {addr}:")
                    
                    messages = content.split('|') 
                    for msg in messages:
                        if msg.strip(): 
                            print(f"   ➥ {msg.strip()}")
                    # ---------------------------------------------
                    
                    sock.sendto(b"ACK", addr)
                    print("-" * 30)
                else:
                    print(f"\n[{time_now}] [!] Lỗi Checksum! Bỏ qua gói.")
            else:
                print(f"[{time_now}] Nhận tin thường: {raw_msg}")
                sock.sendto(b"ACK", addr)
                
        except Exception as e:
            print(f"Lỗi: {e}")

if __name__ == "__main__":
    udp_server()