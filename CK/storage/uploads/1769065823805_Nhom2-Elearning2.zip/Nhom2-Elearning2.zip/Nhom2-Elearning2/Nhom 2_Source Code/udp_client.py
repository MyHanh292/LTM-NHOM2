import socket
import time
import hashlib
import os

os.system('chcp 65001 > nul')

SERVER_IP = "127.0.0.1"
SERVER_PORT = 8888
CLIENT_PORT = 8889
ACK_TIMEOUT = 2.0
MAX_RETRIES = 3

def strong_checksum(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:8]

def udp_client():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("", CLIENT_PORT))
    sock.settimeout(ACK_TIMEOUT)

    print("      UDP CLIENT - TỐI ƯU HÓA TRUYỀN TẢI")
    print(" Gõ 'send' để gửi gom gói, 'exit' để thoát.")
    
    msg_buffer = []
    while True:
        msg = input(" Nhập tin nhắn > ")
        
        if msg.lower() == "exit": break
        if msg.lower() == "send":
            if not msg_buffer: continue
            
            full_content = '|'.join(msg_buffer)
            checksum = strong_checksum(full_content.encode('utf-8'))
            send_data = f"{full_content}<CHK:{checksum}>"
            
            success = False
            for i in range(MAX_RETRIES):
                try:
                    print(f"  ... Đang gửi (Lần {i+1})")
                    sock.sendto(send_data.encode('utf-8'), (SERVER_IP, SERVER_PORT))
                    ack, _ = sock.recvfrom(1024)
                    if ack == b"ACK":
                        print("  [✓] Server đã nhận thành công!")
                        success = True
                        break
                except socket.timeout:
                    print("  [!] Timeout - Không thấy phản hồi.")
            
            if not success: print("  [X] Gửi thất bại sau nhiều lần thử.")
            msg_buffer = []
        else:
            msg_buffer.append(msg)
    sock.close()

if __name__ == "__main__":
    udp_client()