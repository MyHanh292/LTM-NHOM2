Tối ưu hóa UDP
Nhóm áp dụng 4 kỹ thuật tối ưu UDP gồm: Reliable UDP (ACK & Retransmission), Timeout, Batching/Unbatching và Checksum.
Server gửi ACK để xác nhận gói tin hợp lệ, client tự tái truyền khi timeout nếu mất gói.
Dữ liệu được gom nhiều tin nhắn gửi một lần, server tách lại bằng ký hiệu ➥ để giảm số gói tin.
Toàn vẹn dữ liệu được đảm bảo bằng SHA256 checksum.
Kết quả: Ứng dụng hoạt động ổn định và đảm bảo không mất dữ liệu ngay cả khi mạng không ổn định.